# [[file:chapter_4.org::setup-chapter-4-1][setup-chapter-4-1]]
from functools import reduce
from itertools import product
from typing import Any

# Importing sympy takes a few houndred milliseconds
import sympy as sp
from sympy import cos, exp, I, Matrix, pi, sin, sqrt
from sympy.physics.quantum import TensorProduct
from sympy.combinatorics import Permutation as Perm

import numpy as np
import numpy.typing as npt
# setup-chapter-4-1 ends here

# [[file:chapter_4.org::paulis-and-friends][paulis-and-friends]]
# The Paulis:
X = Matrix([[0, 1], [1, 0]])
Y = Matrix([[0, -I], [I, 0]])
Z = Matrix([[1, 0], [0, -1]])

# Identity
Id = Matrix([[1, 0], [0, 1]])
# Hadamard Gate
H = Matrix([[1, 1], [1, -1]]) / sqrt(2)
# Phase Gate (sqrt(Z))
S = Matrix([[1, 0], [0, I]])
# pi/8 Gate
T = Matrix([[1, 0], [0, exp(pi * I / 4)]])

# Rotation Operators
# - Rz: Phase Shift
# - Rx: "Strange" Rotation
# - Ry: Real Rotation
theta = sp.symbols('theta', real=True)
Rz = Matrix([[exp(-I*theta/2), 0], [0, exp(I*theta/2)]])
Rx = Matrix([[cos(theta/2), -I*sin(theta/2)], [-I*sin(theta/2), cos(theta/2)]])
Ry = Matrix([[cos(theta/2), -sin(theta/2)], [sin(theta/2), cos(theta/2)]])
# paulis-and-friends ends here

# [[file:chapter_4.org::swap-gate][swap-gate]]
SWAP = Matrix([
  [1, 0, 0, 0],
  [0, 0, 1, 0],
  [0, 1, 0, 0],
  [0, 0, 0, 1]
])
# swap-gate ends here

# [[file:chapter_4.org::projection-operators][projection-operators]]
# First define the projections onto the computational basis
P0 = Matrix([[1, 0], [0, 0]])
P1 = Matrix([[0, 0], [0, 1]])


def tprod(A1, *As):
    """Generalize TensorProduct to one and more then two arguments."""
    P = A1
    for A in As:
        P = TensorProduct(P, A)
    return P
# projection-operators ends here

# [[file:chapter_4.org::controlled-pauli-gates][controlled-pauli-gates]]
# controlled X (NOT), Y, and Z gates
CX = tprod(P0, Id) + tprod(P1, X)
CY = tprod(P0, Id) + tprod(P1, Y)
CZ = tprod(P0, Id) + tprod(P1, Z)


def make_CU(num_wires: int, control: int, target: int, U: Matrix) -> Matrix:
    """Returns a controlled U Gate. U must be single qubit gate. Wires are
    numbered 0 to num_wires - 1."""
    assert 0 <= control < num_wires, "control out of range"
    assert 0 <= target < num_wires, "target out of range"
    assert control != target, "target must differ from control"
    assert U.rows == U.cols == 2, "U must be single-qubit gate"

    t0 = [Id]*num_wires
    t1 = [Id]*num_wires

    t0[control] = P0
    t1[control] = P1
    t1[target] = U

    return tprod(*t0) + tprod(*t1)
# controlled-pauli-gates ends here

# [[file:chapter_4.org::other-controlled-gates][other-controlled-gates]]
# Toffoli Gate aka CCX
Toff = tprod(P0, P0, Id) + tprod(P0, P1, Id) + tprod(P1, P0, Id) + tprod(P1, P1, X)

# Fredkin Gate aka CSWAP
Fred = tprod(P0, Id, Id) + tprod(P1, SWAP)
# other-controlled-gates ends here

# [[file:chapter_4.org::make-CnU-gates][make-CnU-gates]]
def make_CnU(num_wires: int, controls: list[int], target: int, U: Matrix) -> Matrix:
    """Generalization of make_CU to several controls."""
    assert all([0 <= c < num_wires for c in controls]), "controls out of range"
    assert 0 <= target < num_wires, "target out of range"
    assert all([c != target for c in controls]), "target must differ from controls"
    assert U.rows == U.cols == 2, "U must be single-qubit gate"

    P = [P0, P1]

    CnU = None
    ts = []
    for bitlist in product(*[[0, 1]]*len(controls)):
        t = [Id]*num_wires

        for i, bit in enumerate(bitlist):
            t[controls[i]] = P[bit]

        ts.append(t)
    ts[-1][target] = U

    tensors = [tprod(*t) for t in ts]
    CnU = None
    for tensor in tensors:
        CnU = tensor if CnU is None else CnU + tensor

    return CnU
# make-CnU-gates ends here

# [[file:chapter_4.org::make-two-level-gates][make-two-level-gates]]
def make_twolevel(dim: int, indices: list[int], row: list) -> Matrix:
    """Make a two level unitary matrix essentially by giving an unnormalized row.

    Let i,j=indices, a,b=row, n=norm((a,b)). The resulting unitary matrix U satisfies
    (U_{ii},U_{ij}=(a,b)/n if i<j, else (U_{ij},U_{ii}=(a,b)/n. The other is derived from
    conjugation, like that (a,b) -> (-b*,a*).
    """
    assert len(indices) == len(row) == 2, "Expected only two indices/rows."
    assert all([0 <= i < dim for i in indices]), "Indices out of range."
    i, j = indices
    assert i != j, "Indices must not be equal."
    i1, j1 = sorted([i, j])

    U = [[1 if i == j else 0 for j in range(dim)] for i in range(dim)]

    norm = sqrt(row[0]*row[0].conjugate() + row[1]*row[1].conjugate())
    r0, r1 = row[0]/norm, row[1]/norm

    U[i][i1], U[i][j1] = r0, r1
    U[j][i1], U[j][j1] = -r1.conjugate(), r0.conjugate()

    return Matrix(U)


def make_onelevel(dim: int, index: int, factor) -> Matrix:
    """Make a diagonal matrix with `factor` at position `index`."""
    U = [[1 if i == j else 0 for j in range(dim)] for i in range(dim)]
    U[index][index] = factor
    return Matrix(U)
# make-two-level-gates ends here

# [[file:chapter_4.org::search-for-circuits-approach-via-sympy][search-for-circuits-approach-via-sympy]]
def make_all_CU(num_wires: int, U: Matrix, name: str, pred=None) -> list[Any]:
    """Generate all CU gates, whose control/target wires satisfy an optional predicate."""
    if pred is None:
        pred = (lambda c, t: True)

    # All possible combinations of (control, target).
    all_cts = list(product(range(num_wires), range(num_wires)))
    all_cts = [(c, t) for (c, t) in all_cts if c != t and pred(c, t)]

    gates = []
    for c, t in all_cts:
        gate = make_CU(num_wires, c, t, U)
        gates.append(dict(  # The output is a list of dicts
            name=name,
            ct=(c, t),
            gate=gate,
        ))

    return gates


def sp_search_circuits(n: int, admissible_gates: list[Matrix], Wanted_Gate: Matrix) -> str:
    """Find all circuits with n gates implementing Wanted_Gate."""
    solutions = []
    for gates in product(*([admissible_gates]*n)):
        gs = [g["gate"] for g in gates]
        prod = reduce((lambda x, y: x*y), gs)
        if sp.simplify(prod) == Wanted_Gate:  # wanted gate should already be simplified
            solutions.append(" * ".join([f"{g['name']}{g['ct']}" for g in gates]))
    return solutions
# search-for-circuits-approach-via-sympy ends here

# [[file:chapter_4.org::numpy-make-controlled-gates][numpy-make-controlled-gates]]
def np_kron(A1: npt.ArrayLike, *As: list[npt.ArrayLike]) -> np.ndarray:
    """Generalize TensorProduct to one and more then two arguments."""
    P = A1
    for A in As:
        P = np.kron(P, A)
    return P


def np_make_CU(num_wires: int, control: int, target: int, U: np.ndarray) -> np.ndarray:
    """Returns a controlled U Gate. U must be single qubit gate. Wires are
    numbered 0 to num_wires - 1."""
    assert 0 <= control < num_wires, "control out of range"
    assert 0 <= target < num_wires, "target out of range"
    assert control != target, "target must differ from control"
    assert U.shape == (2, 2), "U must be single-qubit gate"

    t0 = [np_Id]*num_wires
    t1 = [np_Id]*num_wires

    t0[control] = np_P0
    t1[control] = np_P1
    t1[target] = U

    return np_kron(*t0) + np_kron(*t1)


def np_make_CnU(num_wires: int, controls: list[int], target: int, U: np.ndarray) -> np.ndarray:
    """Generalization of make_CU to several controls."""
    assert all([0 <= c < num_wires for c in controls]), "controls out of range"
    assert 0 <= target < num_wires, "target out of range"
    assert all([c != target for c in controls]), "target must differ from controls"
    assert U.shape == (2, 2), "U must be single-qubit gate"

    P = [np_P0, np_P1]

    CnU = None
    ts = []
    for bitlist in product(*[[0, 1]]*len(controls)):
        t = [np_Id]*num_wires

        for i, bit in enumerate(bitlist):
            t[controls[i]] = P[bit]

        ts.append(t)
    ts[-1][target] = U

    tensors = [np_kron(*t) for t in ts]
    CnU = None
    for tensor in tensors:
        CnU = tensor if CnU is None else CnU + tensor

    return CnU
# numpy-make-controlled-gates ends here

# [[file:chapter_4.org::*Implementation of the search routine][Implementation of the search routine:1]]
def np_make_all_CU(num_wires: int, U: Matrix, name: str, pred=None) -> list[Any]:
    if pred is None:
        pred = (lambda c, t: True)

    pairs = list(product(range(num_wires), range(num_wires)))
    pairs = [(c, t) for (c, t) in pairs if c != t and pred(c, t)]

    gates = []
    for c, t in pairs:
        gate = np_make_CU(num_wires, c, t, U)
        gates.append(dict(
            name=name,
            ct=(c, t),
            gate=gate,
        ))

    return gates


def np_make_all_C2U(num_wires: int, U: np.ndarray, name: str, pred=None) -> list[Any]:
    if pred is None:
        pred = (lambda c, t: True)

    triples = list(product(*([range(num_wires)]*3)))
    triples = [(c0, c1, t) for (c0, c1, t) in triples if c0 < c1 and c0 != t and c1 != t and pred((c0, c1), t)]

    gates = []
    for c0, c1, t in triples:
        gate = np_make_CnU(num_wires, [c0, c1], t, U)
        gates.append(dict(
            name=name,
            ct=((c0, c1), t),
            gate=gate,
        ))

    return gates


def np_search_circuit(n: int, admissible_gates: list[np.ndarray], Wanted_Gate: np.ndarray) -> str:
    """Find all solutions to exercise 4.28 with n gates."""
    solutions = []
    for gates in product(*([admissible_gates]*n)):
        gs = [g["gate"] for g in gates]
        prod = reduce((lambda x, y: x @ y), gs)
        if np.alltrue(prod == Wanted_Gate):
            solutions.append(" @ ".join([f"{g['name']}{g['ct']}" for g in gates]))
    return solutions


def make_pred_CX(num_wires):
    def pred_CX(c, t):
        return c < t and t < num_wires - 1
    return pred_CX


def make_pred_CV(num_wires: int):
    def pred_CV(c, t):
        return c < t and t == num_wires - 1
    return pred_CV


def make_pred_CCX(num_wires: int):
    def pred_CCX(c, t):
        return c[0] < t and c[1] < t and t < num_wires - 1
    return pred_CCX
# Implementation of the search routine:1 ends here

# [[file:chapter_4.org::numpy-paul-matrices][numpy-paul-matrices]]
np_X = np.array([[0, 1], [1, 0]])
np_Y = np.array([[0, -1j], [1j, 0]])
np_Z = np.array([[1, 0], [0, -1]])

np_Id = np.eye(2)
np_P0 = np.array([[1, 0], [0, 0]])
np_P1 = np.array([[0, 0], [0, 1]])

# Half-integral-numbers should be OK too since floats are binary
np_V = np.array([[1 - 1j, 1 + 1j], [1 + 1j, 1 - 1j]]) / 2
np_Vt = np_V.conj().T
# numpy-paul-matrices ends here

# [[file:chapter_4.org::exercise-4-27-1][exercise-4-27-1]]
# cx3ij means: control i, target j
cx301 = Perm(4, 6)(5, 7)
cx302 = Perm(4, 5)(6, 7)
cx312 = Perm(2, 3)(6, 7)
cx310 = Perm(2, 6)(3, 7)
cx320 = Perm(1, 5)(3, 7)
cx321 = Perm(1, 3)(5, 7)

# t3i means: target at qubit i
t30 = Perm(3, 7)
t31 = Perm(5, 7)
t32 = Perm(6, 7)
# exercise-4-27-1 ends here

# [[file:chapter_4.org::exercise-4-27-2][exercise-4-27-2]]
def search_ex4_27(n: int):
    """Find all solutions to exercise 4.27 with n gates."""
    perms = [cx301, cx302, cx312, cx310, cx320, cx321, t30, t31, t32]
    names = ["cx301", "cx302", "cx312", "cx310", "cx320", "cx321", "t30", "t31", "t32"]
    indices = list(range(len(perms)))

    for idxs in product(*([indices]*n)):
        ps = [perms[i] for i in idxs]
        prod = reduce((lambda x, y: x*y), ps)
        if prod == Perm(1, 2, 3, 4, 5, 6, 7):
            print(" * ".join([names[i] for i in idxs]))
# exercise-4-27-2 ends here
