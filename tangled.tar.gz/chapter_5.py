# [[file:chapter_5.org::chapter-5-python-imports][chapter-5-python-imports]]
import math
import random
from fractions import Fraction
from numbers import Integral
from typing import Optional, Union

import sympy as sp
from qiskit import (AncillaRegister, ClassicalRegister, QuantumCircuit, QuantumRegister,
                    transpile)
from qiskit.circuit import ControlledGate, Gate
from qiskit.circuit.library import SwapGate
from qiskit_aer import AerSimulator
from sympy import I, exp, pi
# chapter-5-python-imports ends here

# [[file:chapter_5.org::*Code from earlier Chapters][Code from earlier Chapters:1]]
from chapter_4 import Rz, theta
from continued_fractions import get_convergent
# Code from earlier Chapters:1 ends here

# [[file:chapter_5.org::chapter-5-Rk][chapter-5-Rk]]
k = sp.symbols('k', integer=True)
Rk = sp.simplify(exp(2*pi*I*2**(-k-1)) * Rz.subs(theta, 2*pi*2**(-k)))
# chapter-5-Rk ends here

# [[file:chapter_5.org::*Quantum Fourier Transform][Quantum Fourier Transform:2]]
def make_qft(size: Integral) -> Gate:
    qc = QuantumCircuit(size)

    def append_rotations(qc: QuantumCircuit, size: Integral):
        if size == 0:
            return

        qc.h(size - 1)
        for i in range(size - 1, 0, -1):  # reversed order makes a nicer plot
            qc.cp(math.pi * 2**(-i), size - 1, size - i - 1)

        append_rotations(qc, size - 1)

    def append_swaps(qc, size):
        for i in range(size // 2):
            qc.swap(i, size - i - 1)

    append_rotations(qc, size)
    append_swaps(qc, size)

    return qc.to_gate(label="QFT")


def make_qft_dg(size: Integral) -> Gate:
    qft = make_qft(size)
    return qft.definition.inverse().to_gate(label="QFT^†")
# Quantum Fourier Transform:2 ends here

# [[file:chapter_5.org::*Addition in Fourier Space][Addition in Fourier Space:1]]
def make_control_prefix(num_ctrls: int):
    return "" if num_ctrls == 0 else "c"*num_ctrls + "_"


class FourierIncrementGate(Gate):
    """Implements |ϕ(j)> -> |ϕ(a+j)> where a is the increment."""

    def __init__(self, num_qubits: int, increment: int,
                 label: Optional[str] = None):
        """Create a new Fourier incrementer gate."""
        super().__init__(f"ϕinc({increment})", num_qubits, [], label=label)
        assert 2**num_qubits > increment, \
            f"Increment {increment} is too large for {num_qubits} bits."
        self._increment = increment

    def _define(self):
        qc = QuantumCircuit(self._num_qubits)

        for k in range(self._num_qubits):
            qc.p(2*math.pi*self._increment*2**(-self._num_qubits+k), k)

        self.definition = qc
# Addition in Fourier Space:1 ends here

# [[file:chapter_5.org::*Addition in Fourier Space][Addition in Fourier Space:2]]
class IncrementGate(Gate):
    """Implements |j> -> |a+j> where a is the increment."""

    def __init__(self, num_qubits: int, increment: int,
                 label: Optional[str] = None):
        """Create a new incrementer gate."""
        super().__init__(f"inc({increment})", num_qubits, [], label=label)
        assert 2**num_qubits > increment, \
            f"Increment {increment} is too large for {num_qubits} bits."
        self._increment = increment

    def _define(self):
        qc = QuantumCircuit(self._num_qubits)
        finc = FourierIncrementGate(self._num_qubits, self._increment)
        qft = make_qft(self._num_qubits)
        qft_dg = make_qft_dg(self._num_qubits)

        qc.append(qft, range(self._num_qubits))
        qc.append(finc, range(self._num_qubits))
        qc.append(qft_dg, range(self._num_qubits))

        self.definition = qc
# Addition in Fourier Space:2 ends here

# [[file:chapter_5.org::*Addition in Fourier Space][Addition in Fourier Space:4]]
def modulus_size(modulus: int):
    return (modulus - 1).bit_length()


def make_modular_fourier_incrementer(increment: int, modulus: int, num_ctrls: int=0) -> Gate:
    """Implements |ϕ(j)> -> |ϕ(a+j mod N)> where a is the increment and N the modulus.

    Args:
        increment: The fixed increment hardcoded into the circuit.
        modulus: The modulus hardcoded into the circuit.
        num_ctrls: This many control qubits are added before all other qubits.

    Note: The last wire is an ancillary qubit which needs to be initialized to |0>.
    """
    size = modulus_size(modulus) + 1

    qreg_ctrl = QuantumRegister(num_ctrls, "c")
    qreg = QuantumRegister(size, "q")
    qreg_anc = QuantumRegister(1, "a")

    qreg2 = list(qreg_ctrl) + list(qreg)

    qc = QuantumCircuit(qreg_ctrl, qreg, qreg_anc)

    inc_a = FourierIncrementGate(size, increment)
    cc_inc_a = inc_a if num_ctrls == 0 else inc_a.control(num_ctrls)
    inc_N = FourierIncrementGate(size, modulus)
    c_inc_N = FourierIncrementGate(size, modulus).control(1)
    cc_inc_a_dg = cc_inc_a.inverse()
    inc_N_dg = inc_N.inverse()
    qft = make_qft(size)
    qft_dg = make_qft_dg(size)

    qc.append(cc_inc_a, qreg2)
    qc.append(inc_N_dg, qreg)

    qc.append(qft_dg, qreg)
    qc.cx(qreg[-1], qreg_anc[0])
    qc.append(qft, qreg)

    qc.append(c_inc_N, list(qreg_anc) + list(qreg))
    qc.append(cc_inc_a_dg, qreg2)

    qc.append(qft_dg, qreg)
    qc.cx(qreg[-1], qreg_anc[0], ctrl_state=0)
    qc.append(qft, qreg)

    qc.append(cc_inc_a, qreg2)

    prefix = make_control_prefix(num_ctrls)
    return qc.to_gate(label=f"{prefix}ϕinc({increment})mod({modulus})")


class ModularFourierIncrementGate(Gate):
    """Implements |ϕ(j)> -> |ϕ(a+j mod N)>."""

    def __init__(self, increment: int, modulus: int,
                 label: Optional[str] = None):
        """Create a new modular Fourier incrementer gate.

        Args:
            increment: The increment 'a' hardcoded into the circuit.
            modulus: The modulus 'N' hardcoded into the circuit.

        Note: The last wire is an ancillary qubit which needs to be initialized to |0>.
        """
        num_qubits = modulus_size(modulus) + 2
        super().__init__(f"ϕinc({increment})mod({modulus})", num_qubits, [], label=label)
        self._increment = increment
        self._modulus = modulus

    def _define(self):
        qc = make_modular_fourier_incrementer(self._increment, self._modulus).definition
        self.definition = qc

    def control(
            self,
            num_ctrl_qubits: int = 1,
            label: Optional[str] = None,
            ctrl_state: Optional[Union[str, int]] = None,
    ):
        gate = MCModularFourierIncrementGate(
            self._increment, self._modulus, num_ctrl_qubits)
        gate.base_label = self.label
        return gate


class MCModularFourierIncrementGate(ControlledGate):
    """Implements controlled version of |ϕ(j)> -> |ϕ(a+j mod N)>."""

    def __init__(
            self,
            increment: int,
            modulus: int,
            num_ctrl_qubits: int,
            ctrl_state: Optional[Union[str, int]] = None,
            label: Optional[str] = None):
        """Create a new modular Fourier incrementer gate.

        Args:
            increment: The increment 'a' hardcoded into the circuit.
            modulus: The modulus 'N' hardcoded into the circuit.
            num_ctrl_qubits: The number of controls added to the front.

        Note: The last wire is an ancillary qubit which needs to be initialized to |0>.
        """
        assert ctrl_state is None, "sorry ctrl_state not implemented"
        super().__init__(
            "mcfinc",
            num_ctrl_qubits + modulus_size(modulus) + 2,
            [],
            num_ctrl_qubits=num_ctrl_qubits,
            base_gate=ModularFourierIncrementGate(increment, modulus, label=label),
            label=label,
        )
        self._increment = increment
        self._modulus = modulus

    def _define(self):
        qc = make_modular_fourier_incrementer(
            self._increment, self._modulus, self.num_ctrl_qubits).definition
        self.definition = qc
# Addition in Fourier Space:4 ends here

# [[file:chapter_5.org::*Addition in Fourier Space][Addition in Fourier Space:6]]
class ModularIncrementGate(Gate):
    """Implements |j> -> |a+j mod N>."""

    def __init__(self, increment: int, modulus: int,
                 label: Optional[str] = None):
        """Create a new modular incrementer gate.

        Args:
            increment: The increment 'a' hardcoded into the circuit.
            modulus: The modulus 'N' hardcoded into the circuit.

        Note: The last wire is an ancillary qubit which needs to be initialized to |0>.
        """
        num_qubits = modulus_size(modulus) + 2
        super().__init__(f"inc({increment})mod({modulus})", num_qubits, [], label=label)
        self._increment = increment
        self._modulus = modulus

    def _define(self):
        mfinc = ModularFourierIncrementGate(self._increment, self._modulus)

        qreg_size = mfinc.num_qubits - 1  # one ancilla

        qft = make_qft(qreg_size)
        qft_dg = make_qft_dg(qreg_size)

        qc = QuantumCircuit(qreg_size + 1)

        qc.append(qft, range(qreg_size))
        qc.append(mfinc, range(qreg_size + 1))
        qc.append(qft_dg, range(qreg_size))

        self.definition = qc
# Addition in Fourier Space:6 ends here

# [[file:chapter_5.org::*Addition in Fourier Space][Addition in Fourier Space:8]]
def quantum_add(a: int, b: int, modulus: int = None, size: int = None) -> int:
    """Compute a + b or a + b mod modulus.

    Args:
        a,b: The two summands.
        size: The number of qubits to represent a and b. Ignored if modulus is given.
        modulus: Some number required to be larger than a and b.

    Note:
        Uses make_incrementer or make_modular_incrementer depending whether modulus is
        given or not.
    """
    assert a >= 0 and b >= 0, "a and b must be positive"

    if modulus is None:
        assert size is not None, "Specify 'size'"
        inc = IncrementGate(size, a)
        qc = QuantumCircuit(size)
    else:
        assert a < modulus and b < modulus, "a and b must be smaller than modulus"
        inc = ModularIncrementGate(a, modulus)
        size = inc.num_qubits
        qc = QuantumCircuit(size)

    # Not nice but works: Implicitly treats ancilla for the modular case correctly.
    qc.initialize(f"{b:0{size}b}")
    qc.append(inc, range(size))
    qc.measure_all()

    sim = AerSimulator()
    qc_obj = transpile(qc, sim)
    counts = sim.run(qc_obj).result().get_counts()

    largest_count = 0
    for bits, count in counts.items():
        if count > largest_count:
            largest_count = count
            result = int(bits, base=2)

    return result
# Addition in Fourier Space:8 ends here

# [[file:chapter_5.org::*Multiplication in Fourier Space][Multiplication in Fourier Space:1]]
def make_VaN(a: int, modulus: int, num_ctrls: int = 0, fast_mode=True) -> Gate:
    """Implements |x,b> -> |x,b+ax mod N>.

    Args:
        fast_mode: Usage of ModularFourierIncrementGate slows down everything dramatically,
            use make_modular_fourier_incrementer directly in case of fast_mode=True.
    """
    int_size = modulus_size(modulus) + 1

    qreg_ctrl = QuantumRegister(num_ctrls, "c")
    qreg_x = QuantumRegister(int_size, "x")
    qreg_b = QuantumRegister(int_size, "b")
    qreg_anc = AncillaRegister(1, "a")

    qft = make_qft(int_size) if num_ctrls == 0 else make_qft(int_size).control(num_ctrls)
    qft_dg = make_qft_dg(int_size) if num_ctrls == 0 else make_qft_dg(int_size).control(num_ctrls)

    qc = QuantumCircuit(qreg_ctrl, qreg_x, qreg_b, qreg_anc)

    qc.append(qft, list(qreg_ctrl) + list(qreg_b))

    for i in range(int_size - 1):
        ai = a * 2**i % modulus

        if fast_mode:
            cfinc = make_modular_fourier_incrementer(ai, modulus, num_ctrls=num_ctrls + 1)
        else:
            cfinc = ModularFourierIncrementGate(ai, modulus).control(num_ctrls + 1)

        qc.append(cfinc, list(qreg_ctrl) + [qreg_x[i]] + list(qreg_b) + list(qreg_anc))

    qc.append(qft_dg, list(qreg_ctrl) + list(qreg_b))

    prefix = make_control_prefix(num_ctrls)
    return qc.to_gate(label=f"{prefix}(b + {a}x mod {modulus})")
# Multiplication in Fourier Space:1 ends here

# [[file:chapter_5.org::*Multiplication in Fourier Space][Multiplication in Fourier Space:3]]
def make_UaN(a: int, modulus: int, num_ctrls: int = 0) -> Gate:
    """Implements |x> -> |ax mod N>."""
    L = modulus_size(modulus) + 1

    qreg_ctrl = QuantumRegister(num_ctrls, "c")
    qreg = QuantumRegister(L, "q")
    qreg_anc = AncillaRegister(L + 1, "a")

    VaN = make_VaN(a, modulus, num_ctrls)
    Va1N = make_VaN(pow(a, -1, modulus), modulus, num_ctrls)
    Va1N_dg = Va1N.definition.inverse().to_gate(label=f"{Va1N.label}^†")

    qc = QuantumCircuit(qreg_ctrl, qreg, qreg_anc)

    qc.append(VaN, list(qreg_ctrl) + list(qreg) + list(qreg_anc))

    for i in range(qreg.size - 1):  # last bit just for overflow
        swap = SwapGate() if num_ctrls == 0 else SwapGate().control(num_ctrls)
        qc.append(swap, list(qreg_ctrl) + [qreg[i], qreg_anc[i]])

    qc.append(Va1N_dg, list(qreg_ctrl) + list(qreg) + list(qreg_anc))

    # FIXME: for some weird reason I *must* convert this to_gate here (and convert it back during
    # usage) to make the transpile step work.
    return qc.to_gate()


class UaNGate(Gate):
    """Implements |x> -> |ax mod N>."""

    def __init__(
            self, a: int,
            modulus: int,
            label: Optional[str] = None,
    ):
        """Create a new U(a, N) gate."""
        L = modulus_size(modulus) + 1
        num_qubits = 2*L + 1
        super().__init__(
            f"{a}x mod {modulus}",
            num_qubits,
            [],
            label=label,
        )
        self._increment = a
        self._modulus = modulus

    def _define(self):
        qc = make_UaN(self._increment, self._modulus).definition
        self.definition = qc


class MCUaNGate(ControlledGate):
    """Implements controlled version of |x> -> |ax mod N>."""

    def __init__(
            self, a: int,
            modulus: int,
            num_ctrl_qubits: int,
            ctrl_state: Optional[Union[str, int]] = None,
            label: Optional[str] = None,
    ):
        """Create a new CU(a, N) gate."""
        assert ctrl_state is None, "sorry ctrl_state not implemented"
        L = modulus_size(modulus) + 1
        num_qubits = 2*L + 1
        super().__init__(
            f"mcuan",
            num_qubits + num_ctrl_qubits,
            [],
            num_ctrl_qubits=num_ctrl_qubits,
            label=label,
            base_gate=UaNGate(a, modulus),
        )
        self._increment = a
        self._modulus = modulus

    def _define(self):
        qc = make_UaN(self._increment, self._modulus, num_ctrls=self.num_ctrl_qubits).definition
        self.definition = qc
# Multiplication in Fourier Space:3 ends here

# [[file:chapter_5.org::*Implementation][Implementation:1]]
def eps_bits(eps: float) -> int:
    """Number of additional qubits required to guarantee a success
    probability of at least 1-eps (theoretically). See Chapter 5.2.1."""
    assert eps > 0, "eps must be strictly positive."
    return math.ceil(math.log(2.0 + 0.5/eps))


def make_order_finding_phase_estimation(a: int, modulus: int, eps: float) -> QuantumCircuit:
    """Make a phase estimation circuit to find the order of 'a'."""
    L = modulus_size(modulus)
    t = 2*L + 1 + eps_bits(eps)

    qreg_top = QuantumRegister(t, "t")
    qreg_bot = QuantumRegister(L + 1, "u")  # one qubit for overflow
    qreg_anc = AncillaRegister(L + 2, "a")
    creg = ClassicalRegister(t, "c")

    qc = QuantumCircuit(qreg_top, qreg_bot, qreg_anc, creg)

    for i in range(t):
        qc.h(qreg_top[i])

    qc.x(qreg_bot[0])

    for i in range(t):
        CUai = MCUaNGate(pow(a, 2**i, modulus), modulus, num_ctrl_qubits=1)
        qc.append(CUai, [qreg_top[i]] + list(qreg_bot) + list(qreg_anc))
        pass

    qft_dg = make_qft_dg(t)
    qc.append(qft_dg, qreg_top)

    for i in range(t):
        qc.measure(qreg_top[i], creg[i])

    return qc
# Implementation:1 ends here

# [[file:chapter_5.org::*Factoring][Factoring:1]]
def is_even(N: int) -> bool:
    return N % 2 == 0


def intlogx(N: int, base: int, offset=0, exponent=1) -> int:
    """Largest n such that (offset + base**n)**exponent <= N

    For offset=0 and exponent=1 this is just floor(log_base(x))."""
    assert 1 < base < N

    n = 1
    a = base
    while (value := (offset + a)**exponent) < N:
        a *= base
        n += 1

    return n if value == N else n - 1


def is_power(N: int) -> int:
    """Decide whether there is x, k > 1 such that x**k = N.

    Returns: None if not, and *a* pair (x, k) as above otherwise."""
    k2 = intlogx(N, 2)

    # For each k <= k2 check if there is an x with x**k == N
    for k in range(2, k2 + 1):
        x = 0
        # This loop attempts to construct the binary representation of x:
        while x**k < N:
            i = intlogx(N, 2, offset=x, exponent=k)
            x += 2**i

        if x**k == N:
            return x, k

    return None
# Factoring:1 ends here

# [[file:chapter_5.org::*Factoring][Factoring:3]]
def get_maximizing_keys(counts: dict[str, int], num: int) -> tuple[str]:
    """Get the 'num' keys of 'counts' with maximal associated values.

    Returns: An *lexicographically* sorted num-tuple of the keys."""
    result = sorted(counts.items(), key=lambda a: a[1], reverse=True)[:num]
    result = [a[0] for a in result]
    return tuple(sorted(result))


def find_factor(N: int, eps=1.0, randrange=None) -> int:
    """Find a non-trivial factor of N - assuming it has one.

    Args:
        N: An integer larger than 1 which is assumed to be not prime.
        eps: A parameter for the phase estimation (smaller values lead to a
            smaller error rate). Must be larger 0.
        randrange: please ignore this parameter, just for testing (sorry).
    """
    assert eps > 0, "eps must be positive."
    assert N > 1, "N must be larger than 1."

    if is_even(N):
        return 2

    if (ret := is_power(N)) is not None:
        return ret[0]

    # Just for testing (sorry):
    randrange = randrange or random.randrange

    while True:
        a = randrange(2, N)
        print(f"Trying a={a}")

        gcd = math.gcd(a, N)
        if gcd > 1:
            return gcd

        # From here on N is a neither even, nor a power. By assumption it is also non-prime.
        qc = make_order_finding_phase_estimation(a, N, eps)
        sim = AerSimulator()
        qc_obj = transpile(qc, sim)

        # Note: on a simulator the number of shots does not significantly influence the
        # running time. This is reasonable since the simulator has access to the wave
        # function form which it can cheaply sample (at least this is how I guess it
        # works).
        counts = sim.run(qc_obj, shots=1000).result().get_counts()

        bit_list = list(counts.keys())
        weights = list(counts.values())
        for i in range(100):  # this simulates 100 independent runs
            bits = random.choices(bit_list, weights)[0]
            print(f"Shot {i} measured {bits}")

            s_div_r = Fraction(int(bits), 2**len(bits))
            convergent = get_convergent(s_div_r, N)
            r = convergent.denominator
            print(f"r={r}")

            if not is_even(r):
                continue

            r2 = r // 2
            x = (a ** r2) % N

            if x != 1:
                gcd = math.gcd(x - 1, N)
                if gcd > 1:
                    return gcd

            if x != N - 1:
                gcd = math.gcd(x + 1, N)
                if gcd > 1:
                    return gcd
# Factoring:3 ends here
