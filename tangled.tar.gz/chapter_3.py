# [[file:chapter_3.org::chapter-3-setup][chapter-3-setup]]
from functools import reduce
from typing import Literal, NewType, Optional
from collections.abc import Callable

from utils import TermColor
# chapter-3-setup ends here

# [[file:chapter_3.org::chapter-3-gather-turing-machine-sources][chapter-3-gather-turing-machine-sources]]
Char = NewType("Char", str)  # better than nothing, represents a letter from the alphabet
State = NewType("State", str)
Move = Literal[-1, 0, +1]
TuringProgLine = tuple[State, Char, State, Char, Move]  # (s,c,s',c',m)
TuringProgram = list[TuringProgLine]

SourceMap = list[tuple[int, str]]
TuringParser = Callable[[str], [tuple[TuringProgram, SourceMap | None]]]
def parse_turing_program_line(line: str) -> TuringProgLine | None:
    """Parse a single line of the form `(s,c,s',c',m)` (up to comments).

    Empty or comment lines are ignored by returning `None`."""
    # Remove comments and leading/trailing whitespace
    line = line[:line.find('#')].strip()
    if len(line) == 0:
        return None  # line comment or empty line

    line = line.strip().lstrip("(").rstrip(")")
    s0, c0, s1, c1, m = line.split(",")
    m = +1 if m == "+" else m  # for convinience ...
    m = -1 if m == "-" else m  # ... allow shortcuts for +1, -1
    m = int(m)
    assert len(c0) == 1, f"Expected character got '{c0}'."
    assert len(c1) == 1, f"Expected character got '{c1}'."
    assert m in [-1, 0, +1], f"Forbidden head movement: {m}."

    return s0, c0, s1, c1, m


def parse_turing_program(source: str) -> tuple[TuringProgram, SourceMap]:
    """Parses the source of a turing program line by line."""
    program: TuringProgram = []
    source_map: list[int] = []

    lines = source.split("\n")
    for line_no, line in enumerate(lines):
        try:
            parsed_line = parse_turing_program_line(line)
        except Exception:
            # Probably good enough for such a simple language:
            raise Exception(f"Could not parse line {line_no}: '{line}'")

        if parsed_line is not None:
            program.append(parsed_line)
            source_map.append((line_no, line))

    return program, source_map
class TuringMachine:
    """Given a turing program produces the corresponding turing machine."""
    BLANK: Char = "■"  # Special symbol for the blank cell. Is used when tape dynamically grows.
    MAX_STEPS = 1000000  # Abort after running this many steps
    LOG_LEVEL = 0  # Set greater 0 for a chatty execution
    COLORED_LOG = True  # Turn of if environment does not support colors
    SOURCE_LINE_OFFSET = 0  # SourceMap assumes that source file start with line 0. Adjust this here.

    def __init__(self, program: TuringProgram,
                 start_state: State = "START", halt_state: State = "HALT",
                 source_map: Optional[SourceMap] = None):
        self._start_state = start_state
        self._halt_state = halt_state
        self._program = program
        self._source_map = source_map

        assert source_map is None or len(source_map) == len(program), "Invalid source_map"

        self._state = None
        self._head_position: int = None
        self._tape: list[Char] = []  # gets input during execution
        self._step_count = None

        # Only relevant for logging:
        self._index_width = len(str(len(self._program)-1))

    @classmethod
    def fromSource(cls, source: str,
                   start_state: State = "START", halt_state: State = "HALT",
                   parser: TuringParser = parse_turing_program) -> "TuringMachine":
        """Create a turing machine from a source string. You can provide a custom parser."""
        program, source_map = parser(source)
        return TuringMachine(program,
                             start_state=start_state, halt_state=halt_state,
                             source_map=source_map)

    def run(self, tape_input: str) -> str:
        """Run the TM and return what is on the tape after it halts."""
        self._state = self._start_state
        self._head_position = 0
        self._tape = list(tape_input)
        self._step_count = 0

        while self._state != self._halt_state:
            if self._step_count > self.MAX_STEPS:
                raise Exception("Turing machine takes too long. Aborting.")
            self._step_count += 1
            self._log(2, f"\nExecuting step {self._step_count}")
            self._run_one_step()

        self._log(1, f"\nExecution took {self._step_count} steps.")

        return self._tape_content.strip(self.BLANK)

    @property
    def _line_no_width(self):  # only relevant for logging
        return None if self._source_map is None \
            else len(str(self._source_map[-1][0] + self.SOURCE_LINE_OFFSET - 1))

    def _log(self, level, *args, **kwargs):
        if self.LOG_LEVEL >= level:
            print(*args, **kwargs)

    def _run_one_step(self) -> None:
        self._log(3, f"tape = '{self._colored_tape_content}'")
        current_line = self._current_program_line

        if current_line is None:
            RED, ENDC = (TermColor.RED, TermColor.ENDC) if self.COLORED_LOG else ("", "")
            self._log(2, f"{RED}No matching program line - halting{ENDC}")
            self._state = self._halt_state
            return

        index, current_line = current_line
        self._log(4, f"program line = {index:{self._index_width}}: {current_line}")

        if self._source_map is not None:
            line_no, source_line = self._source_map[index]
            line_no += self.SOURCE_LINE_OFFSET
            self._log(3, f"source line = {line_no:{self._line_no_width}}: {source_line}")

        s1, c1, m = current_line[2:]

        self._state = s1
        self._head_symbol = c1
        # avoid negative positions:
        self._head_position = max(self._head_position + m, 0)

    @property
    def _tape_content(self) -> str:
        return "".join(self._tape)

    @property
    def _colored_tape_content(self) -> str:
        self._enlarge_tape_if_necessary()
        text = self._tape_content
        pos = self._head_position
        GREEN, ENDC = (TermColor.GREEN, TermColor.ENDC) if self.COLORED_LOG else ("", "")
        return text[:pos] + GREEN + text[pos] + ENDC + text[pos+1:]

    @property
    def _current_program_line(self) -> tuple[int, TuringProgLine]:
        s0, c0 = self._state, self._head_symbol
        self._log(2, f"state='{s0}', symbol='{c0}', head_position={self._head_position}")
        for i, line in enumerate(self._program):
            s, c = line[:2]
            if s0 == s and c0 == c:
                return i, line

        return None

    @property
    def _head_symbol(self) -> Char:
        self._enlarge_tape_if_necessary()
        return self._tape[self._head_position]

    @_head_symbol.setter
    def _head_symbol(self, new_symbol) -> Char:
        self._enlarge_tape_if_necessary()  # just being paranoid
        self._tape[self._head_position] = new_symbol

    def _enlarge_tape_if_necessary(self) -> None:
        """Call this to ensure that our finite tape can actually be accessed at head position."""
        pos = self._head_position
        while pos >= len(self._tape):  # only one loop usually suffices
            some_blanks = [self.BLANK] * (1 + len(self._tape))
            self._tape += some_blanks  # double tape size
# chapter-3-gather-turing-machine-sources ends here

# [[file:chapter_3.org::source-tp-constant-one][source-tp-constant-one]]
source_tp_constant_one="""# This program computes the function f(n)=1.
# Example: input=\"▶1001\", output=\"▶1\".
(S,▶,A,▶,+) # S is the start state
(A,0,A,■,+)
(A,1,A,■,+)
(A,■,B,■,-)
(B,■,B,■,-)
(B,▶,C,▶,+)
(C,■,H,1,0) # H is the halt state
"""
# source-tp-constant-one ends here

# [[file:chapter_3.org::var-source_tp_ex_3_3][var-source_tp_ex_3_3]]
source_tp_ex_3_3="""# Turing program to reverse a string of bits (0s and 1s):
#   - input  : \"▶a...z■...\" where a...z is a string of 0s and 1s
#     followed by at least length-of(a..z)+1 blanks (this is important).
#   - output : \"▶z...a■...\" where z...a is the reversed string.
# The head starts and finishes at \"▶\".

# Note: in the following we assume that the input string is non-empty to simplify
# the analysis of the *generic* case. But it is easy to check that this corner case
# also works. This is more or less an accident as you can see by the fact that we rely
# on the fact that (by our definition) a Turing machine halts if no matching line is
# found.

#
##
### Part 1: Map ▶a...z■...■ to ▶□...□z...a
##
#

# In part 1 the tape always contains \"▶\" followed by a bitstring A, followed
# by a series W of *white* blanks (special markers), followed by a bitstring B.
# Initially B and W are empty and A is the input string. At the end A is empty,
# W is at its place, and B contains the reversed string.

# B1: At the beginning we just step into A
# Pre-Conditions:
#   - tape content is \"▶\" followed by A, followed by blanks
#   - A is non-empty, W and B are empty
#   - Head is at \"▶\"
# Post-Conditions:
#   - Head is at the beginning of A
#   - tape content is unchanged (by the action of this block)
# Successor Blocks: B1.
(START,▶,a,▶,+) # entry and exit

# B2: Move the head to the end of A
# Pre-Conditions:
#   - Head is inside A,
#   - A is followed by at least one blank.
# Post-Conditions:
#   - Head is at last bit of A (points at 0 or 1)
#   - tape content is unchanged
# Successor Blocks: B3
(a,0,a,0,+) # entry
(a,1,a,1,+) # entry
(a,■,b,■,-) # exit

# B3: Special case if B still empty: Move the last bit of A one step to the right.
# Pre-Conditions:
#   - Head is at last bit of A
#   - B is empty, A is followed by blanks
# Post-Conditions:
#   - Last bit of A replaced by *white* blank and moved one step to right;
#   - B consists of one bit;
#   - Head is inside W
# Successor Blocks: B4
(b,0,b0,□,+) # entry
(b,1,b1,□,+) # entry
(b0,■,c,0,-) # exit
(b1,■,c,1,-) # exit

# B4: Traverse to the left over a series of white blanks
# Pre-Conditions:
#   - Head is inside W
#   - B is non-empty (but A might be empty)
# Post-Conditions:
#   - Head is at the last bit of A or at \"▶\" if A is empty
# Successor Blocks: B5, B7
(c,□,c,□,-) # entry and exit

# B5: Move the right-most bit of A to the end of B.
# Pre-Conditions:
#   - A and B are non-empty
#   - Head is at the last bit of A
# Post-Conditions:
#   - Head is inside B
# Successor Blocks: B6
(c,0,c0,□,+) # entry
(c,1,c1,□,+) # entry
# Move over the white blanks and then past the end of B:
(c0,□,c0,□,+)
(c0,0,c0,0,+)
(c0,1,c0,1,+)
(c1,□,c1,□,+)
(c1,0,c1,0,+)
(c1,1,c1,1,+)
# Append the remembered bit to the end of B
(c0,■,d,0,-) # exit
(c1,■,d,1,-) # exit

# B6: Go from B (back) to the white blanks
# Pre-Conditions:
#   - Head is inside B
# Post-Condition:
#   - Head is inside W
# Successor Blocks: B4
(d,0,d,0,-) # entry
(d,1,d,1,-) # entry
(d,□,c,□,-) # exit

#
##
### Part 2: Map ▶□...□z...a to ▶z...a□...□
##
#

# In part 2 the tape always contains \"▶\" followed by a bitstring C, followed
# by a series W of *white* blanks, followed by a bitstring B.
# Initially C is empty and B is the reversed input string. At the end B is empty,
# W is at its place, and C contains the left-shifted version of B.

# B7: Entrypoint for part 2 of the algorithm. Move into W.
# Pre-Conditions:
#   - Every bit of A was replaced by white blanks - now W
#   - B is reversed version of the initial value of A (and non-empty)
#   - Head is at ▶
# Post-Conditions:
#   - Head is at first white blank - in W
#   - tape content is unchanged
# Successor Blocks: B8
(c,▶,e,▶,+) # entry and exit

# B8: Traverse to the right over a series of white blanks
# Pre-Conditions:
#   - Head is inside W
# Post-Conditions:
#   - Head is at the end of B or at the first blank (after B)
# Successor Blocks: B9, B10
(e,□,e,□,+) # entry and exit

# B9: Erase the first bit of B and append it to C
# Pre-Conditions:
#   - Head is at first bit of B (which is non-empty)
# Post-Conditions:
#   - Bit was replaced by white blank and appended to end of C
#     or put directly after \"▶\" if C is empty
#   - Head is past the end of C, points to a white blank (inside W)
# Successor Blocks: B8
(e,0,f0,□,-) # entry
(e,1,f1,□,-) # entry
(f0,□,f0,□,-)
(f1,□,f1,□,-)
# Reaching end of C or ▶ if C is empty
(f0,▶,g0,▶,+)
(f0,0,g0,0,+)
(f0,1,g0,1,+)
(f1,▶,g1,▶,+)
(f1,0,g1,0,+)
(f1,1,g1,1,+)
# Append the remembered bit
(g0,□,e,0,+) # exit
(g1,□,e,1,+) # exit

#
##
### Part 3: Map ▶z...a□...□ to ▶z...a
##
#

# This just removes the trailing *white* blanks.

# B10: Remove the trailing white blanks
# Pre-Conditions:
#   - The tape contains the desired result (C) but followed by some white blanks
#   - Head is at the last of the white blanks
# Post-Conditions:
#   - The white blanks are all removed (replaced by blanks)
#   - Head is at \"▶\"
#   - Turing Machine is in halting state
# Successor Blocks: None (halts upon exit)
(e,■,h,■,-) # entry
(h,□,h,■,-)
(h,0,h,0,-)
(h,1,h,1,-)
(h,▶,HALT,▶,0) # exit
"""
# var-source_tp_ex_3_3 ends here

# [[file:chapter_3.org::source-tp-ex-3-4][source-tp-ex-3-4]]
source_tp_ex_3_4="""# Turing machine to add modulo 2
#   - input  : \"▶xxx■yyy■■...\" where xxx and yyy are strings of 0s and 1s of equal length
#     followed by at least 2 blanks. x and y can be empty.
#   - output : \"▶zzz■...\" where zzz is the bitwise sum of xxx and yyy, followed by at
#     least n+2 blanks, where n is the length of x (and also of y).
# The head starts and finishes at \"▶\".

# (A)
# Prepare the input by marking the gap between x and y and the cell after y with white
# blanks (□)
(START,▶,prepare-gap,▶,+)
(prepare-gap,0,prepare-gap,0,+)
(prepare-gap,1,prepare-gap,1,+)
(prepare-gap,■,prepare-end,□,+)  # we assume only one gap cell!
(prepare-end,0,prepare-end,0,+)
(prepare-end,1,prepare-end,1,+)
(prepare-end,■,search-start,□,-)  # note: after that, head cell contains no ■
# Successors: (B)

# (B)
# Search the start marker ▶
(search-start,0,search-start,0,-)
(search-start,1,search-start,1,-)
(search-start,□,search-start,□,-)
(search-start,▶,begin-update-next-bit,▶,+)
# Successors: (C), (D)

# (C)
# Memorize next bit of x by a state, and its position by marking it with a
# blank cell.
(begin-update-next-bit,0,memorize-0,■,+)
(begin-update-next-bit,1,memorize-1,■,+)
# Successors: (E), (F)

# (D)
# Final steps:
#   - replace all the □ (we wrote ourselves) by ■
#   - move the head back to ▶,
#   - and halt!
(begin-update-next-bit,□,cleanup,■,+)
(cleanup,□,cleanup,■,+)
(cleanup,■,finalize,■,-)  # here we need that the input is followed by 2 blanks
(finalize,■,finalize,■,-)
(finalize,0,finalize,0,-)
(finalize,1,finalize,1,-)
(finalize,▶,HALT,▶,0)
# Successors: None (halts)

# (E)
# Traverse the rest of x (which might be empty)
(memorize-0,0,memorize-0,0,+)
(memorize-0,1,memorize-0,1,+)
(memorize-1,0,memorize-1,0,+)
(memorize-1,1,memorize-1,1,+)
# Successors: (F)

# (F)
# Traverse the gap between x and y (y is not empty here since initially it had the
# same length as x)
(memorize-0,□,memorize-0y,□,+)
(memorize-1,□,memorize-1y,□,+)
(memorize-0y,□,memorize-0y,□,+)
(memorize-1y,□,memorize-1y,□,+)
# Successors: (G)

# (G)
# Memorize the bitwise sum of the two corresponding bits
(memorize-0y,0,memorize-sum-0,□,-)
(memorize-0y,1,memorize-sum-1,□,-)
(memorize-1y,0,memorize-sum-1,□,-)
(memorize-1y,1,memorize-sum-0,□,-)
# Successors: (H)

# (H)
# Now we know the sum - transport it leftward
(memorize-sum-0,0,memorize-sum-0,0,-)
(memorize-sum-0,1,memorize-sum-0,1,-)
(memorize-sum-0,□,memorize-sum-0,□,-)
(memorize-sum-1,0,memorize-sum-1,0,-)
(memorize-sum-1,1,memorize-sum-1,1,-)
(memorize-sum-1,□,memorize-sum-1,□,-)
# Successors: (I)

# (I)
# Write the result to the marked position in x
(memorize-sum-0,■,begin-update-next-bit,0,+)
(memorize-sum-1,■,begin-update-next-bit,1,+)
# Successors: (C), (D)
"""
# source-tp-ex-3-4 ends here

# [[file:chapter_3.org::exercise-3.17-1][exercise-3.17-1]]
def find_largest_if_not(x: int, factp: Callable[[int, int], bool]) -> int:
    """Find the largest integer 1<=d<=x such that factp(x, l) is false.
    Return 1 if none exists.

    Preconditions:
      - x >= 1
      - factp(x, l) is defined for l=1,...,x
      - If factp(x, l) is true for some l then so is factp(x, l+1)
      - Either factp(x, l) is true of all l>sqrt(x) or it is always false.

    In case of the factor problem factp(x, l) is true if x has a non-trivial divisor strictly
    smaller than l.

    Note: The third precondition is stricter than needed but it is satisfied for the
    factor problem."""
    if x == 1:  # corner case
        return 1

    # Find the smallest power of two for which factp is true (if it exists)
    k = 1
    while not factp(x, 2**k):
        k = k + 1
        if 2**k > x:
            # Here x is prime if factp is decides the Factor problem. In the general case
            # we rely on the third precondition here!
            return x

    # Here x is not prime if factp decides the Factor problem.

    # d *will* be the smallest number with the desired property. Right now only the left
    # most bit is correct. The following loop builds up d bit by bit.
    d = 2**(k-1)

    for i in range(k-2, -1, -1):
        d1 = d + 2**i
        if factp(x, d1):
            d = d  # just for explicity
        else:
            d = d1

    return d
# exercise-3.17-1 ends here
