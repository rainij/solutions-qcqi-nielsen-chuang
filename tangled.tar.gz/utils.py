# [[file:utils.org::+begin_src python][No heading:1]]
class TermColor:
    """Standard color sequences for coloring text on terminal.

    Usage:
    print(TermColor.RED + "In red" + TermColor.ENDC + " in normal color")"""
    GREEN = '\033[32m'
    RED = '\033[31m'
    ENDC = '\033[0m'
# No heading:1 ends here

# [[file:utils.org::+begin_src python][No heading:2]]
def commutator(a, b):
    """Commutator [a,b] of a and b."""
    return a*b - b*a
# No heading:2 ends here
