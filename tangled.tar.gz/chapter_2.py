# [[file:chapter_2.org::setup-python-imports][setup-python-imports]]
from itertools import product

import sympy as sp
from sympy import Matrix, PermutationMatrix, sqrt
from sympy.combinatorics import Permutation
# setup-python-imports ends here

# [[file:chapter_2.org::*Bra-Ket][Bra-Ket:1]]
def ket(bits: str) -> Matrix:
    """If bits is a string of '0' and '1' this returns |bits>."""
    vec = [0] * 2**len(bits)
    vec[int(bits, 2)] = 1
    return Matrix(vec)


def bra(bits: str) -> Matrix:
    """If bits is a string of '0' and '1' this returns <bits|."""
    return ket(bits).H
# Bra-Ket:1 ends here

# [[file:chapter_2.org::partial-trace][partial-trace]]
def trace(M: Matrix):  # TODO: what is the correct return type?
    """Returns the sum of the diagonal elements. Requires a square matrix."""
    dim = M.shape[0]
    assert dim == M.shape[1], "M must be square"
    result = 0
    for i in range(dim):
        result += M[i, i]
    return result


def ptrace(M: Matrix, bit_positions: list[int] = None) -> Matrix:
    """Partial Trace. The Matrix must have dimension 2^n. The bit_positions describe
    which bits (from the right) get traced out."""
    dim = M.shape[0]
    assert dim == M.shape[1], "M must be square"
    assert dim.bit_count() == 1, "Dim of M must be 2^n for some n >= 0"
    bit_size = dim.bit_length() - 1
    if bit_positions is not None:
        assert len(bit_positions) > 0, "bit_positions must not be empty"
        assert all(0 <= pos <= bit_size for pos in bit_positions), "Invalid bit_positions"

    if bit_positions is None:  # shortcut
        return Matrix([[trace(M)]])
    if len(bit_positions) == 1 and dim == 2:  # corner case
        return Matrix([[trace(M)]])
    elif len(bit_positions) > 1:
        ps = bit_positions.copy()
        ps.sort()  # IMPORTANT!
        RM = M
        while len(ps) > 0:
            pos = ps.pop()
            RM = ptrace(RM, [pos])
        return RM

    rpos = bit_size - 1 - bit_positions[0]

    mat = [[0]*(dim//2) for _ in range(dim//2)]
    for i, j in product(range(dim//2), range(dim//2)):
        ibits = f"{i:b}".zfill(bit_size - 1)
        jbits = f"{j:b}".zfill(bit_size - 1)
        i0 = int(ibits[:rpos] + "0" + ibits[rpos:], 2)
        i1 = int(ibits[:rpos] + "1" + ibits[rpos:], 2)
        j0 = int(jbits[:rpos] + "0" + jbits[rpos:], 2)
        j1 = int(jbits[:rpos] + "1" + jbits[rpos:], 2)
        mat[i][j] = M[i0, j0] + M[i1, j1]

    return Matrix(mat)
# partial-trace ends here

# [[file:chapter_2.org::exercise-2-77-1][exercise-2-77-1]]
def get_eigenvals_of_ABC(state_vector: Matrix):
    """Calculate eigenvals of subsystems of three-qubit system (for Exercise 2.77)."""
    density = state_vector * state_vector.H
    DA = ptrace(density, [1, 2])
    DB = ptrace(density, [0, 2])
    DC = ptrace(density, [0, 1])

    result = ""
    for S, D in [("A", DA), ("B", DB), ("C", DC)]:
        result += f"Eigenvalues in {S}: {D.eigenvals()}.\n"

    return result
# exercise-2-77-1 ends here
