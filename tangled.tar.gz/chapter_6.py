# [[file:chapter_6.org::chapter-6-python-imports][chapter-6-python-imports]]
import sympy as sp
from sympy.vector import CoordSys3D

from chapter_4 import Ry, theta, Z
# chapter-6-python-imports ends here

# [[file:chapter_6.org::*Setup][Setup:2]]
a, b = sp.symbols('a b', real=True)  # usage for a,b or alpha,beta in the book
c, s = sp.symbols('c s', real=True)  # usage for cosine and sine
# Setup:2 ends here
