# [[file:chapter_6.org::chapter-6-python-imports][chapter-6-python-imports]]
import sympy as sp

from chapter_4 import Ry, theta, Z
# chapter-6-python-imports ends here
