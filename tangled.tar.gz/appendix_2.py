# [[file:appendix_2.org::*Python Libraries][Python Libraries:1]]
from numbers import Number

from sympy import Matrix, PermutationMatrix, det, eye, sqrt
from sympy.combinatorics import Permutation

from chapter_2 import trace
# Python Libraries:1 ends here

# [[file:appendix_2.org::*Solution][Solution:1]]
group_s3 = [[0, 1, 2], [1, 2, 0], [2, 0, 1], [1, 0, 2], [0, 2, 1], [2, 1, 0]]
group_s3 = [Permutation(g) for g in group_s3]

s3_perm = [PermutationMatrix(g).as_explicit() for g in group_s3]
# Solution:1 ends here

# [[file:appendix_2.org::*Solution][Solution:4]]
s3_std = [
    Matrix([[1, 0], [0, 1]]),
    Matrix([[-1, -sqrt(3)], [sqrt(3), -1]]) / 2,
    Matrix([[-1, sqrt(3)], [-sqrt(3), -1]]) / 2,
    Matrix([[-1, 0], [0, 1]]),
    Matrix([[1, -sqrt(3)], [-sqrt(3), -1]]) / 2,
    Matrix([[1, sqrt(3)], [sqrt(3), -1]]) / 2,
]
# Solution:4 ends here

# [[file:appendix_2.org::*Solution][Solution:5]]
U_std = Matrix([
    [sqrt(3)/3, -sqrt(2)/2,  sqrt(6)/6],
    [sqrt(3)/3,  sqrt(2)/2,  sqrt(6)/6],
    [sqrt(3)/3,          0, -sqrt(6)/3]
])
# Solution:5 ends here

# [[file:appendix_2.org::exercise-a2-16][exercise-a2-16]]
def get_fourier_matrix(representations: list[list[Matrix | Number]]) -> Matrix:
    """Get a matrix representation of the Fourier transform F of a group G.

    Args:
        representations: All irreducible representations of G.

    Returns:
        The unitary N×N matrix for F with N = |G|.

    The concrete matrix for F depends on the ordering of the representations
    and the choice of basis for each individual representation.
    """
    assert len(representations) > 0, "Need at least one representation"

    N = len(representations[0])
    ftrafo = []

    assert N > 0, "A group cannot have zero elements (c.f. first represenation)."

    for rep in representations:
        assert len(rep) == N, "Cardinality of all representations must be equal."

        if isinstance(rep[0], Number):
            rep = [Matrix([[r]]) for r in rep]

        dim = len(rep[0].col(0))
        assert all([g.shape == (dim, dim) for g in rep]), \
            f"Inconsistent dimension in {rep}"

        for i in range(dim**2):
            row = [sqrt(dim) * g[i] / sqrt(N) for g in rep]
            ftrafo.append(row)

    return Matrix(ftrafo)
# exercise-a2-16 ends here

# [[file:appendix_2.org::exercise-a2-16-2][exercise-a2-16-2]]
s3_triv = 6*[1]
s3_sign = 3*[1] + 3*[-1]

FT_s3 = get_fourier_matrix([s3_triv, s3_sign, s3_std])
# exercise-a2-16-2 ends here
