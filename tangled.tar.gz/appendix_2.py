# [[file:appendix_2.org::*Python Libraries][Python Libraries:1]]
from sympy import Matrix, sqrt, PermutationMatrix, det, eye
from sympy.combinatorics import Permutation

from chapter_2 import trace
# Python Libraries:1 ends here

# [[file:appendix_2.org::*Solution][Solution:1]]
group_s3 = [[0, 1, 2], [1, 2, 0], [2, 0, 1], [1, 0, 2], [0, 2, 1], [2, 1, 0]]
group_s3 = [Permutation(g) for g in group_s3]

s3_perm = [PermutationMatrix(g).as_explicit() for g in group_s3]
# Solution:1 ends here

# [[file:appendix_2.org::*Solution][Solution:4]]
s3_std = [
    Matrix([[1, 0], [0, 1]]),
    Matrix([[-1, -sqrt(3)], [sqrt(3), -1]]) / 2,
    Matrix([[-1, sqrt(3)], [-sqrt(3), -1]]) / 2,
    Matrix([[-1, 0], [0, 1]]),
    Matrix([[1, -sqrt(3)], [-sqrt(3), -1]]) / 2,
    Matrix([[1, sqrt(3)], [sqrt(3), -1]]) / 2,
]
# Solution:4 ends here

# [[file:appendix_2.org::*Solution][Solution:5]]
U_std = Matrix([
    [sqrt(3)/3, -sqrt(2)/2,  sqrt(6)/6],
    [sqrt(3)/3,  sqrt(2)/2,  sqrt(6)/6],
    [sqrt(3)/3,          0, -sqrt(6)/3]
])
# Solution:5 ends here
