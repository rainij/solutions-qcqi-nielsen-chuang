# [[file:continued_fractions.org::*Some Code!][Some Code!:1]]
from fractions import Fraction
from numbers import Number, Integral, Rational
from typing import Any, Literal
import math
# Some Code!:1 ends here

# [[file:continued_fractions.org::*Some Code!][Some Code!:2]]
OutputFormat = Literal["float"] | Literal["pair"] | Literal["rational"]


def eval_cfrac(*coeffs: list[Number], out_format: OutputFormat = "float", callback=lambda *_: None) -> Any:
    """Evaluate the continued fraction given by coeffs."""
    assert len(coeffs) != 0, "At least one coefficient is required"

    p0, p1 = 0, 1
    q0, q1 = 1, 0

    for xi in coeffs:
        p0, p1 = p1, p1*xi + p0
        q0, q1 = q1, q1*xi + q0

        abort_loop = callback(p1, q1, p0, q0)
        if abort_loop:
            break

    if out_format == "float":
        return p1/q1
    elif out_format == "pair":
        return p1, q1
    elif "rational":
        return Fraction(p1, q1)
    else:
        raise Exception(f"Unknown output format '{out_format}'")
# Some Code!:2 ends here

# [[file:continued_fractions.org::*Some Code!][Some Code!:3]]
def compute_cfrac(val_or_partial_cfrac: Number | list[Number], n: Integral, skip_remainder=False) -> list[Number]:
    """Compute the continued fraction expansion [a_0,...,a_{n-1},z_n] of the first arg.

    If the first arg is already a continued fraction expansion (with the last entry being
    a *real* number) it is modified in place. In any case the result is returned."""
    if isinstance(val_or_partial_cfrac, Number):
        return compute_cfrac([val_or_partial_cfrac], n, skip_remainder=skip_remainder)

    pfrac = val_or_partial_cfrac
    n += 1 - len(pfrac)

    for _ in range(n):
        z = pfrac.pop()
        a = math.floor(z)
        z1 = z % 1

        if z1 == 0:
            pfrac.append(a)
            break
        else:
            pfrac += [a, z1**(-1)]

    return pfrac[:-1] if (z1 != 0 and skip_remainder) else pfrac
# Some Code!:3 ends here

# [[file:continued_fractions.org::*Some Code!][Some Code!:9]]
def get_convergent(value: Rational, limit_denominator: Integral) -> Fraction:
    """Compute the last convergent of 'value' whose denominator is smaller than 'limit_denominator'."""
    # Second arg is just something large enough for what we want:
    cfrac = compute_cfrac(value, limit_denominator)
    result = None

    def callback(p, q, *args):
        nonlocal result
        if q <= limit_denominator:
            result = Fraction(p, q)
        else:
            return True  # no need to further run evalutation

    eval_cfrac(*cfrac, callback=callback)

    return result
# Some Code!:9 ends here
